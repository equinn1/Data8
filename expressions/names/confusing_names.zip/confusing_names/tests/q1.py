test = {
  'name': '',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> round(required_beer_volume, -17)
          1.82e+19
          >>> round(sun_radius)
          695732796
          >>> round(sun_volume, -25)
          1.41e+27
          >>> round(sun_surface_area, -17)
          6.1e+18
          >>> sun_density
          1410
          >>> pi
          3.14159
          >>> round(sun_weight, -27)
          1.989e+30
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
